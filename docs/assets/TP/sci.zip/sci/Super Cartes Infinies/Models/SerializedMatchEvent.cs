﻿namespace Super_Cartes_Infinies.Models
{
    public class SerializedMatchEvent
    {
        public int Id { get; set; }
        public int Index { get; set; }
        public string SerializedEvent { get; set; }
    }
}
