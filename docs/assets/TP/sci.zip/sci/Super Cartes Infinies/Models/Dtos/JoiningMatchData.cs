﻿namespace Super_Cartes_Infinies.Models.Dtos
{
    public class JoiningMatchData
    {
        public Match Match { get; set; }
        public Player PlayerA { get; set; }
        public Player PlayerB { get; set; }
    }
}
